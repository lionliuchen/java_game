package day01.am;
/*
 * 
 * 用于封存地面相关属性的信息
 */

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Ground {
	BufferedImage image;//地面的图片
	int x;//地面的x坐标
	int y;//地面的y坐标
	
	//创建地面的构造器
	public Ground() throws Exception {
		x = 0;
		y = 500;
		image = ImageIO.read(getClass().getResource("ground.png"));
	}
	
	//创建方法，用于控制地面的运动
	public void step() {
		x--;
		if(x == -109) {
			x=0;
		}
	}
}