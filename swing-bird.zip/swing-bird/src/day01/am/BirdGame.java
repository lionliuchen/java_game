package day01.am;
/*
 * 导包
 * Ctrl+shift+o
 */
//继承 拓展类的功能
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BirdGame extends JPanel{
	
	//背景图片
	BufferedImage bg;
	//创建地面
	Ground ground;
	//创建1号柱子
	Column column1;
	//创建2号柱子
	Column column2;
	//创建鸟
	Bird bird;
	//游戏结束的画面
	BufferedImage gameoverimage;
	//游戏结束的状态
	boolean gameOver;
	
	//游戏得分
	int score;
	
	//游戏开始的状态
	boolean started;
	//游戏开始的画面
	BufferedImage startImage;
	
	//创建类的构造器（构造方法）初始化属性   抛出异常
	public BirdGame() throws Exception {
		//初始化背景图片
		bg = ImageIO.read(getClass().getResource("bg.png"));
//		初始化地面
		ground = new Ground();
		//初始化1号柱子
		column1 = new Column(1);
		column2 = new Column(2);
		//初始化鸟
		bird = new Bird();
		//游戏默认是没结束的
		gameOver = false;
		//初始化游戏结束的画面
		gameoverimage = ImageIO.read(getClass().getResource("gameover.png"));
		//初始化分数
		score = 0;
		
		started = false;//游戏默认是没开始的
		startImage = ImageIO.read(getClass().getResource("start.png"));
	}
	
	//主方法，主函数，主程序的入口
	public static void main(String[] args) throws Exception{
		//创建窗体
		JFrame frame = new JFrame();
		//创建面板
		BirdGame panel = new BirdGame();//调用类的构造器
		//设置背景颜色
//		panel.setBackground(Color.gray);
//		panel.setBackground(new Color(200, 100, 100));//都是十进制0~255之间
//		panel.setBackground(new Color(0x0000ff));//十六进制
		//给窗体添加面板
		frame.add(panel);
		//设置标题
		frame.setTitle("今天没吃药，感觉萌萌哒！");
		//设置当关闭窗体的同时退出程序
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//设置窗体大小 （像素）
		frame.setSize(432,644);
		//设置居中
		frame.setLocationRelativeTo(null);
		//设置窗体可见
		frame.setVisible(true);
		panel.action();
	}
	//绘制方法
	public void paint(Graphics g) {//画笔
		//绘制背景图片
		g.drawImage(bg, 0, 0, null);
		//绘制1号柱子
		g.drawImage(column1.image, column1.x-column1.width/2, column1.y-column1.height/2, null);
		//绘制2号柱子
		g.drawImage(column2.image, column2.x-column1.width/2, column2.y-column2.height/2, null);
		//绘制地面图片
		g.drawImage(ground.image, ground.x, ground.y, null);
		
		//创建字体
		Font font = new Font(Font.SANS_SERIF,Font.BOLD, 70);
		g.setFont(font);
		
		//绘制分数
		g.drawString("" + score, 40, 60);
		g.setColor(Color.white);
		g.drawString("" + score, 40-3, 60-3);
		
		//创建可以旋转的坐标系
		Graphics2D g2 = (Graphics2D)g;
		g2.rotate(-bird.alpha,bird.x,bird.y);
		//绘制鸟
		g.drawImage(bird.image, bird.x - bird.width/2, bird.y - bird.height/2, null);
		//将坐标系转回原来，以免影响后面的制图
		g2.rotate(bird.alpha,bird.x,bird.y);
		
		//如果游戏结束了绘制游戏结束的画面
		if(gameOver) {
			g.drawImage(gameoverimage, 0, 0, null);
		}
		
		//如果游戏没开始绘制开始画面
		if(!started) {
			g.drawImage(startImage, 0, 0, null);
		}
	}
	
	//运动方法
	public void action() throws Exception {
		//创建鼠标监听事件
		MouseListener L = new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if(gameOver) {
					try {
						column1 = new Column(1);
						column2 = new Column(2);
						bird = new Bird();
						score = 0;
						gameOver = false;
						started = false;
					}catch (Exception e1) {
						//程序员调试检错，打印错误信息
						e1.printStackTrace();
					}
				}
				else {
					bird.fly();
					started = true;
				}
			}
		};
		//添加鼠标事件到程序中
		addMouseListener(L);
		
		while(true) {//死循环控制地面一直动
			if(!gameOver) {
				if(started) {
					column1.step();//让1号柱子动起来
					column2.step();//让2号柱子动起来
					bird.step();//让鸟动起来
				}
				
				ground.step();//让地面动起来				
				bird.flappy();//让鸟的动画帧切换				
				//如果鸟撞到了地面，游戏结束 或撞到柱子
				if(bird.hit(ground) || bird.hit(column1) || bird.hit(column2)) {
					gameOver = true;
				}
				if(bird.x == column1.x || bird.x == column2.x) {
					score++;
				}
			}
			Thread.sleep(1000/60);//让程序每隔1/60秒动一次
			repaint();//重绘方法
			
		}
	}
}