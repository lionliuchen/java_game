package day01.am;
/*
 * 
 * 用于封存柱子的相关信息
 */

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Column {
	BufferedImage image;//柱子的图片
	int x;//柱子中心点x坐标
	int y;//柱子中心点y坐标
	int width;//柱子图片的宽度
	int height;//柱子图片的高度
	int distance;//两根柱子之间的距离
	int gap;//柱子的缝隙
	
	//柱子的构造器
	public Column(int n) throws Exception {//n代表柱子的编号
		image = ImageIO.read(getClass().getResource("column.png"));
		distance = 245;
		gap = 144;
		width = image.getWidth();//获取柱子图片的宽度
		height = image.getHeight();
		x = 550 + (n-1) * distance;
		y = 152 + (int)(Math.random() * 197);
	}
	
	//创建柱子的运动方法
	public void step() {
		x--;
		if(x == -width/2) {
			x = 2 * distance -width/2;
			y = 152 + (int)(Math.random() * 197);
		}
	}
}