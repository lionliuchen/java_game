package day01.am;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Bird {
	BufferedImage image;//鸟的图片
	int x;//鸟中心点x的坐标
	int y;//鸟中心点y的坐标
	int width;//鸟图片的宽度
	int height;//鸟图片的高度
	int index;//用于计数
	
	BufferedImage[] images;
	
	double v0;//初始速度
	double speed;//鸟的当前速度
	double g;//重力加速度
	double t;//两次运动的时间间隔
	double s;//t时间鸟运动的距离
	
	double alpha;//鸟倾斜的角度
	
	int size;//内框，鸟的实际大小
	
	//创建鸟的构造器
	public Bird() throws Exception {
		image = ImageIO.read(getClass().getResource("0.png"));
		x = 132;
		y = 280;
		width = image.getWidth();
		height = image.getHeight();
		
		images = new BufferedImage[8];
		
		for(int i=0;i<images.length;i++) {
			images[i] = ImageIO.read(getClass().getResource(i + ".png"));
		}
		index = 0;
		v0 = 20;
		speed = v0;
		t = 0.25;
		s = 0;
		g = 4;
		
		alpha =0;
		
		size = 40;
		
	}
	//用于控制鸟的动画帧的切换
	public void flappy() {
		image = images[(index++/12)%images.length];
	}
	//鸟运动的方法
	public void step() {
		double v0 = speed;
		s = v0 * t - g * t * t/2;
		speed = v0 - g * t;
		y = y - (int)s;
		
		alpha = Math.atan(s/15);
		
		/*if(y>500) {
			y = 280;
			speed = 40;
		}*/
	}
	//点击鼠标的时候鸟的运动方式
	public void fly() {
		speed = 20;
	}
	
	//鸟碰撞地面的逻辑
	public boolean hit(Ground ground) {
		boolean hit = y > ground.y - size/2;
		if(hit) {
			y = ground.y - size/2;
			alpha = -3.14/2;
		}
		return hit;
	}
	//判断鸟碰撞柱子的方法
	public boolean hit(Column column) {
		if(x > column.x - column.width/2 - size/2 && x < column.x + column.width/2 + size/2) {
			if(y > column.y - column.gap/2 + size/2 && y < column.y + column.gap/2 - size/2) {
				return false;
			}
			return true;
		}
		return false;
	}
}